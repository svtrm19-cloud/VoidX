
  # SITE DE ESCOLA

  This is a code bundle for SITE DE ESCOLA. The original project is available at https://www.figma.com/design/HKmYemj8BW9KWoR4EaeC9j/SITE-DE-ESCOLA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  