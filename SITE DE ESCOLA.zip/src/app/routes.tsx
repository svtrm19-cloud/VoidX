import { createBrowserRouter } from "react-router";
import { VoidLayout } from "./layouts/VoidLayout";
import { VoidDashboard } from "./pages/VoidDashboard";
import { VoidIA } from "./pages/VoidIA";
import { VoidJournal } from "./pages/VoidJournal";
import { VoidStats } from "./pages/VoidStats";
import { VoidProfile } from "./pages/VoidProfile";
import { VoidMode } from "./pages/VoidMode";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: VoidLayout,
    children: [
      { index: true, Component: VoidDashboard },
      { path: "ai", Component: VoidIA },
      { path: "journal", Component: VoidJournal },
      { path: "stats", Component: VoidStats },
      { path: "profile", Component: VoidProfile },
      { path: "void", Component: VoidMode },
    ],
  },
]);
