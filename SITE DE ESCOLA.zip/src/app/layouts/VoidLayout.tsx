import { Outlet, NavLink } from "react-router";
import { Brain, Sparkles, BookOpen, BarChart3, User, Circle } from "lucide-react";

export function VoidLayout() {
  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-black to-black"></div>
      <div className="fixed inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSA2MCAwIEwgMCAwIDAgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgxMzksIDkyLCAyNDYsIDAuMDUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40"></div>

      {/* Glow Effects */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>

      {/* Content */}
      <div className="relative z-10 pb-24">
        <Outlet />
      </div>

      {/* Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-2xl bg-black/40 border-t border-purple-500/20">
        <div className="max-w-lg mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-blue-400"
                    : "text-gray-500 hover:text-blue-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <Brain className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-blue-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">NEURAL</span>
                </>
              )}
            </NavLink>

            <NavLink
              to="/ai"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-purple-400"
                    : "text-gray-500 hover:text-purple-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <Sparkles className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-purple-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">VOID IA</span>
                </>
              )}
            </NavLink>

            <NavLink
              to="/journal"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-cyan-400"
                    : "text-gray-500 hover:text-cyan-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <BookOpen className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-cyan-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">DIÁRIO</span>
                </>
              )}
            </NavLink>

            <NavLink
              to="/stats"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-pink-400"
                    : "text-gray-500 hover:text-pink-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <BarChart3 className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-pink-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">DADOS</span>
                </>
              )}
            </NavLink>

            <NavLink
              to="/profile"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-violet-400"
                    : "text-gray-500 hover:text-violet-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <User className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-violet-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">PERFIL</span>
                </>
              )}
            </NavLink>

            <NavLink
              to="/void"
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all duration-300 group ${
                  isActive
                    ? "text-indigo-400"
                    : "text-gray-500 hover:text-indigo-300"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className={`relative ${isActive ? 'animate-pulse' : ''}`}>
                    <Circle className="w-6 h-6" />
                    {isActive && (
                      <div className="absolute inset-0 bg-indigo-500/30 rounded-full blur-lg"></div>
                    )}
                  </div>
                  <span className="text-[10px] font-bold tracking-wider">VOID</span>
                </>
              )}
            </NavLink>
          </div>
        </div>
      </nav>
    </div>
  );
}
