import { useState, useEffect } from "react";
import { BookOpen, Plus, Trash2, Brain, Calendar, Clock } from "lucide-react";

interface JournalEntry {
  id: string;
  content: string;
  timestamp: number;
  emotion: string;
  intensity: number;
}

export function VoidJournal() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [newEntry, setNewEntry] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("voidmind_journal");
    if (stored) {
      setEntries(JSON.parse(stored));
    }
  }, []);

  const analyzeEmotion = (text: string): { emotion: string; intensity: number } => {
    const lowerText = text.toLowerCase();

    if (lowerText.includes("ansiedade") || lowerText.includes("ansioso") || lowerText.includes("preocup")) {
      return { emotion: "Ansiedade", intensity: 75 };
    } else if (lowerText.includes("triste") || lowerText.includes("sozinho") || lowerText.includes("vazio")) {
      return { emotion: "Melancolia", intensity: 68 };
    } else if (lowerText.includes("feliz") || lowerText.includes("alegre") || lowerText.includes("bem")) {
      return { emotion: "Alegria", intensity: 85 };
    } else if (lowerText.includes("raiva") || lowerText.includes("irritado") || lowerText.includes("bravo")) {
      return { emotion: "Raiva", intensity: 70 };
    } else if (lowerText.includes("calm") || lowerText.includes("paz") || lowerText.includes("tranquil")) {
      return { emotion: "Serenidade", intensity: 90 };
    } else if (lowerText.includes("pens") || lowerText.includes("reflet") || lowerText.includes("contempla")) {
      return { emotion: "Contemplação", intensity: 82 };
    } else {
      return { emotion: "Neutro", intensity: 50 };
    }
  };

  const handleSaveEntry = () => {
    if (!newEntry.trim()) return;

    setIsAnalyzing(true);

    setTimeout(() => {
      const analysis = analyzeEmotion(newEntry);
      const entry: JournalEntry = {
        id: Date.now().toString(),
        content: newEntry,
        timestamp: Date.now(),
        emotion: analysis.emotion,
        intensity: analysis.intensity,
      };

      const updatedEntries = [entry, ...entries];
      setEntries(updatedEntries);
      localStorage.setItem("voidmind_journal", JSON.stringify(updatedEntries));
      setNewEntry("");
      setIsAnalyzing(false);
    }, 1500);
  };

  const handleDeleteEntry = (id: string) => {
    const updatedEntries = entries.filter(e => e.id !== id);
    setEntries(updatedEntries);
    localStorage.setItem("voidmind_journal", JSON.stringify(updatedEntries));
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  };

  const getEmotionColor = (emotion: string) => {
    const colors: Record<string, string> = {
      Ansiedade: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10",
      Melancolia: "text-blue-400 border-blue-500/30 bg-blue-500/10",
      Alegria: "text-green-400 border-green-500/30 bg-green-500/10",
      Raiva: "text-red-400 border-red-500/30 bg-red-500/10",
      Serenidade: "text-cyan-400 border-cyan-500/30 bg-cyan-500/10",
      Contemplação: "text-purple-400 border-purple-500/30 bg-purple-500/10",
      Neutro: "text-gray-400 border-gray-500/30 bg-gray-500/10",
    };
    return colors[emotion] || colors.Neutral;
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="backdrop-blur-xl bg-black/40 border-b border-purple-500/20 px-6 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-cyan-400" />
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Diário Mental
              </h1>
              <p className="text-xs text-gray-400 tracking-wider">INTERFACE DE REGISTRO NEURAL • ANÁLISE EMOCIONAL</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        {/* New Entry */}
        <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-cyan-500/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <Brain className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">Novo Registro Neural</h3>
          </div>

          <textarea
            value={newEntry}
            onChange={(e) => setNewEntry(e.target.value)}
            placeholder="Registre seus pensamentos, emoções e reflexões..."
            className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all min-h-[150px] resize-none"
          />

          <div className="flex items-center justify-between mt-4">
            <div className="text-xs text-gray-500">
              {newEntry.length} caracteres
            </div>
            <button
              onClick={handleSaveEntry}
              disabled={!newEntry.trim() || isAnalyzing}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-xl font-bold hover:from-cyan-600 hover:to-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Analisando...</span>
                </>
              ) : (
                <>
                  <Plus className="w-5 h-5" />
                  <span>Salvar Registro</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Entries List */}
        <div className="space-y-4">
          {entries.length === 0 ? (
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-white/10 p-12 text-center">
              <BookOpen className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 text-lg mb-2">Nenhum registro ainda</p>
              <p className="text-gray-600 text-sm">Comece a documentar sua jornada mental</p>
            </div>
          ) : (
            entries.map((entry) => (
              <div
                key={entry.id}
                className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/20 p-6 hover:border-purple-500/40 transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className={`px-3 py-1 rounded-lg border ${getEmotionColor(entry.emotion)} text-xs font-bold`}>
                      {entry.emotion}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(entry.timestamp)}</span>
                      <Clock className="w-3 h-3 ml-2" />
                      <span>{formatTime(entry.timestamp)}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDeleteEntry(entry.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                <p className="text-gray-300 leading-relaxed mb-4">{entry.content}</p>

                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-500">Intensidade Emocional</span>
                      <span className="text-xs text-purple-400 font-bold">{entry.intensity}%</span>
                    </div>
                    <div className="h-1.5 bg-black/40 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-1000"
                        style={{ width: `${entry.intensity}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {/* Neural Analysis */}
                <div className="mt-4 pt-4 border-t border-white/5">
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Brain className="w-3 h-3 text-purple-400" />
                    <span>Padrão Neural: {entry.emotion} detectado com {entry.intensity}% de intensidade</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Stats */}
        {entries.length > 0 && (
          <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-2xl border border-purple-500/30 p-6">
            <h3 className="text-lg font-bold text-purple-400 mb-4">Estatísticas do Diário</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <div className="text-gray-400 text-xs mb-1">Total de Registros</div>
                <div className="text-2xl font-bold text-white">{entries.length}</div>
              </div>
              <div>
                <div className="text-gray-400 text-xs mb-1">Mais Frequente</div>
                <div className="text-2xl font-bold text-purple-400">
                  {entries.length > 0
                    ? entries.reduce((acc, e) => {
                        acc[e.emotion] = (acc[e.emotion] || 0) + 1;
                        return acc;
                      }, {} as Record<string, number>)
                    : {}}
                  {Object.entries(
                    entries.reduce((acc, e) => {
                      acc[e.emotion] = (acc[e.emotion] || 0) + 1;
                      return acc;
                    }, {} as Record<string, number>)
                  ).sort((a, b) => b[1] - a[1])[0]?.[0] || "N/A"}
                </div>
              </div>
              <div>
                <div className="text-gray-400 text-xs mb-1">Intensidade Média</div>
                <div className="text-2xl font-bold text-blue-400">
                  {Math.round(entries.reduce((sum, e) => sum + e.intensity, 0) / entries.length)}%
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
