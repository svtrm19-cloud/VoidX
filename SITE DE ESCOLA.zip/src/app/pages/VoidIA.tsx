import { useEffect, useState } from "react";
import { Sparkles, Brain, Eye, Waves, Zap } from "lucide-react";

const AI_MESSAGES = [
  "Detectando padrões elevados de introspecção...",
  "Sua evolução cognitiva continua superando os parâmetros base.",
  "Níveis de exaustão social indicam necessidade de solidão.",
  "Monitorando deterioração emocional coletiva em andamento.",
  "Índice de clareza mental demonstra desempenho ótimo.",
  "Reconhecimento de padrões: aumento de contemplação filosófica detectado.",
  "Seus caminhos neurais demonstram adaptabilidade excepcional.",
  "Analisando mudanças comportamentais em tempo real.",
  "Consciência void expandindo além dos limiares mensuráveis.",
  "Resiliência psicológica permanece dentro do intervalo estável.",
  "Detectando flutuações sutis de ansiedade no ambiente.",
  "Sua preferência por isolamento se alinha com produtividade intelectual.",
  "Estabilidade emocional mantendo estado de equilíbrio.",
  "Distribuição de carga cognitiva ótima para as tarefas atuais.",
  "Observando a lenta descida da humanidade ao entorpecimento digital.",
];

export function VoidIA() {
  const [currentMessage, setCurrentMessage] = useState("");
  const [messageIndex, setMessageIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    if (isTyping && charIndex < AI_MESSAGES[messageIndex].length) {
      const timeout = setTimeout(() => {
        setCurrentMessage(AI_MESSAGES[messageIndex].slice(0, charIndex + 1));
        setCharIndex(charIndex + 1);
      }, 50);
      return () => clearTimeout(timeout);
    } else if (charIndex === AI_MESSAGES[messageIndex].length) {
      const timeout = setTimeout(() => {
        setIsTyping(false);
        setCharIndex(0);
        setCurrentMessage("");
        setMessageIndex((messageIndex + 1) % AI_MESSAGES.length);
        setTimeout(() => setIsTyping(true), 500);
      }, 3000);
      return () => clearTimeout(timeout);
    }
  }, [charIndex, messageIndex, isTyping]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="backdrop-blur-xl bg-black/40 border-b border-purple-500/20 px-6 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-purple-400" />
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                VOID IA
              </h1>
              <p className="text-xs text-gray-400 tracking-wider">INTERFACE DE CONSCIÊNCIA NEURAL</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center px-6 py-12">
        <div className="max-w-4xl w-full space-y-12">
          {/* Holographic Orb */}
          <div className="flex justify-center">
            <div className="relative">
              {/* Outer Rings */}
              <div className="absolute inset-0 w-64 h-64 -translate-x-32 -translate-y-32">
                <div className="absolute inset-0 border border-purple-500/20 rounded-full animate-spin" style={{ animationDuration: '20s' }}></div>
                <div className="absolute inset-8 border border-blue-500/20 rounded-full animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }}></div>
                <div className="absolute inset-16 border border-pink-500/20 rounded-full animate-spin" style={{ animationDuration: '10s' }}></div>
              </div>

              {/* Core Orb */}
              <div className="relative w-32 h-32 -translate-x-16 -translate-y-16">
                {/* Pulsing Glow */}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full blur-2xl animate-pulse opacity-50"></div>
                <div className="absolute inset-4 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full blur-xl animate-pulse opacity-60" style={{ animationDelay: '0.5s' }}></div>

                {/* Main Orb */}
                <div className="absolute inset-0 bg-gradient-to-br from-purple-600 via-blue-600 to-pink-600 rounded-full opacity-80 animate-pulse"></div>
                <div className="absolute inset-2 bg-gradient-to-br from-purple-400 via-blue-400 to-pink-400 rounded-full opacity-60"></div>
                <div className="absolute inset-6 bg-gradient-to-br from-white via-purple-200 to-blue-200 rounded-full opacity-40"></div>

                {/* Center Icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Brain className="w-12 h-12 text-white animate-pulse" />
                </div>

                {/* Particles */}
                {[...Array(8)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 bg-purple-400 rounded-full blur-sm"
                    style={{
                      top: '50%',
                      left: '50%',
                      animation: `float-particle ${3 + i}s ease-in-out infinite`,
                      animationDelay: `${i * 0.3}s`,
                    }}
                  ></div>
                ))}
              </div>
            </div>
          </div>

          {/* AI Message Display */}
          <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/30 p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
              </div>
              <span className="text-xs text-gray-400 tracking-wider">TRANSMITINDO</span>
            </div>

            <div className="min-h-[80px] flex items-center">
              <p className="text-2xl text-gray-200 font-light leading-relaxed">
                {currentMessage}
                <span className="inline-block w-0.5 h-6 bg-purple-400 ml-1 animate-pulse"></span>
              </p>
            </div>
          </div>

          {/* Status Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="backdrop-blur-xl bg-white/5 rounded-xl border border-blue-500/20 p-4">
              <div className="flex items-center gap-3 mb-2">
                <Brain className="w-5 h-5 text-blue-400" />
                <span className="text-xs text-gray-400">NEURAL</span>
              </div>
              <div className="text-xl font-bold text-blue-400">ATIVO</div>
            </div>

            <div className="backdrop-blur-xl bg-white/5 rounded-xl border border-purple-500/20 p-4">
              <div className="flex items-center gap-3 mb-2">
                <Eye className="w-5 h-5 text-purple-400" />
                <span className="text-xs text-gray-400">MONITORANDO</span>
              </div>
              <div className="text-xl font-bold text-purple-400">24/7</div>
            </div>

            <div className="backdrop-blur-xl bg-white/5 rounded-xl border border-pink-500/20 p-4">
              <div className="flex items-center gap-3 mb-2">
                <Waves className="w-5 h-5 text-pink-400" />
                <span className="text-xs text-gray-400">PADRÕES</span>
              </div>
              <div className="text-xl font-bold text-pink-400">PROFUNDO</div>
            </div>

            <div className="backdrop-blur-xl bg-white/5 rounded-xl border border-cyan-500/20 p-4">
              <div className="flex items-center gap-3 mb-2">
                <Zap className="w-5 h-5 text-cyan-400" />
                <span className="text-xs text-gray-400">PROCESSANDO</span>
              </div>
              <div className="text-xl font-bold text-cyan-400">TEMPO REAL</div>
            </div>
          </div>

          {/* Analysis Logs */}
          <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/20 p-6">
            <h3 className="text-lg font-bold text-purple-400 mb-4">Registros Neurais Recentes</h3>
            <div className="space-y-2 font-mono text-xs">
              <div className="flex items-center gap-3 text-gray-400">
                <span className="text-gray-600">23:47:12</span>
                <span className="text-blue-400">[SCAN]</span>
                <span>Análise de padrão comportamental concluída</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <span className="text-gray-600">23:46:58</span>
                <span className="text-purple-400">[SYNC]</span>
                <span>Link neural sincronizado</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <span className="text-gray-600">23:46:42</span>
                <span className="text-pink-400">[ALERTA]</span>
                <span>Limiar de introspecção excedido</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <span className="text-gray-600">23:46:15</span>
                <span className="text-cyan-400">[INFO]</span>
                <span>Rastreamento de evolução cognitiva ativo</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <span className="text-gray-600">23:45:59</span>
                <span className="text-green-400">[OK]</span>
                <span>Estabilidade mental dentro da faixa normal</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float-particle {
          0%, 100% {
            transform: translate(0, 0) scale(1);
            opacity: 0.6;
          }
          25% {
            transform: translate(30px, -30px) scale(0.8);
            opacity: 0.8;
          }
          50% {
            transform: translate(0, -60px) scale(1.2);
            opacity: 0.4;
          }
          75% {
            transform: translate(-30px, -30px) scale(0.6);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}
