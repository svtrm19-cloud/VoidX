import { User, Brain, Zap, Target, Eye, Award, TrendingUp, Shield, Settings } from "lucide-react";

export function VoidProfile() {
  const level = 82;
  const xp = 15420;
  const nextLevelXp = 20000;
  const xpProgress = (xp / nextLevelXp) * 100;

  const attributes = [
    { name: "Foco Mental", value: 85, max: 100, icon: Eye, color: "cyan" },
    { name: "Disciplina", value: 78, max: 100, icon: Target, color: "purple" },
    { name: "Clareza", value: 90, max: 100, icon: Brain, color: "blue" },
    { name: "Energia", value: 72, max: 100, icon: Zap, color: "pink" },
    { name: "Resiliência", value: 88, max: 100, icon: Shield, color: "violet" },
    { name: "Evolução", value: 92, max: 100, icon: TrendingUp, color: "indigo" },
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, any> = {
      cyan: { text: "text-cyan-400", bg: "bg-cyan-500", glow: "shadow-cyan-500/50" },
      purple: { text: "text-purple-400", bg: "bg-purple-500", glow: "shadow-purple-500/50" },
      blue: { text: "text-blue-400", bg: "bg-blue-500", glow: "shadow-blue-500/50" },
      pink: { text: "text-pink-400", bg: "bg-pink-500", glow: "shadow-pink-500/50" },
      violet: { text: "text-violet-400", bg: "bg-violet-500", glow: "shadow-violet-500/50" },
      indigo: { text: "text-indigo-400", bg: "bg-indigo-500", glow: "shadow-indigo-500/50" },
    };
    return colors[color];
  };

  const achievements = [
    { name: "Pioneiro Neural", icon: Brain, color: "blue", unlocked: true },
    { name: "Caminhante do Vazio", icon: Eye, color: "purple", unlocked: true },
    { name: "Mestre da Mente", icon: Target, color: "cyan", unlocked: true },
    { name: "Pensador Profundo", icon: Award, color: "pink", unlocked: false },
    { name: "Sábio da Evolução", icon: TrendingUp, color: "violet", unlocked: false },
    { name: "Buscador de Clareza", icon: Zap, color: "indigo", unlocked: true },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="backdrop-blur-xl bg-black/40 border-b border-purple-500/20 px-6 py-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <User className="w-6 h-6 text-violet-400" />
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
                  Perfil Neural
                </h1>
                <p className="text-xs text-gray-400 tracking-wider">MATRIZ DE IDENTIDADE PSICOLÓGICA</p>
              </div>
            </div>
            <button className="w-10 h-10 backdrop-blur-xl bg-white/5 rounded-xl border border-white/10 flex items-center justify-center hover:border-purple-500/50 transition-all">
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        {/* Profile Card */}
        <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-2xl border border-purple-500/40 p-8 relative overflow-hidden">
          {/* Background Effect */}
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSA2MCAwIEwgMCAwIDAgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjA1KSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>

          <div className="relative flex items-start gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl blur-xl animate-pulse"></div>
              <div className="relative w-24 h-24 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center border-4 border-purple-400/50">
                <div className="text-3xl font-bold text-white">SV</div>
              </div>
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-4 border-black flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1">
              <h2 className="text-3xl font-bold text-white mb-2">Samuel Victor</h2>
              <div className="flex items-center gap-3 mb-4">
                <div className="px-3 py-1 bg-purple-500/20 backdrop-blur-sm border border-purple-500/40 rounded-lg">
                  <span className="text-sm font-bold text-purple-300">Nível {level}</span>
                </div>
                <div className="px-3 py-1 bg-blue-500/20 backdrop-blur-sm border border-blue-500/40 rounded-lg">
                  <span className="text-sm font-bold text-blue-300">Neural ID: #VX-2024</span>
                </div>
                <div className="flex items-center gap-1 px-3 py-1 bg-green-500/20 backdrop-blur-sm border border-green-500/40 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-bold text-green-300">ON-LINE</span>
                </div>
              </div>

              {/* XP Progress */}
              <div className="mb-3">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-400">Experiência Neural</span>
                  <span className="text-purple-400 font-bold">{xp.toLocaleString()} / {nextLevelXp.toLocaleString()} XP</span>
                </div>
                <div className="h-3 bg-black/40 rounded-full overflow-hidden backdrop-blur-sm">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full shadow-lg shadow-purple-500/50 transition-all duration-1000"
                    style={{ width: `${xpProgress}%` }}
                  ></div>
                </div>
              </div>

              <p className="text-gray-300 text-sm">
                Consciência neural avançada. Especializado em introspecção profunda, evolução cognitiva e análise psicológica.
              </p>
            </div>
          </div>
        </div>

        {/* Neural Attributes */}
        <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            Atributos Neurais
          </h3>

          <div className="grid md:grid-cols-2 gap-4">
            {attributes.map((attr) => {
              const colors = getColorClasses(attr.color);
              const Icon = attr.icon;
              const percentage = (attr.value / attr.max) * 100;

              return (
                <div key={attr.name} className="backdrop-blur-sm bg-black/20 rounded-xl border border-white/10 p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br from-${attr.color}-500/20 to-transparent border border-${attr.color}-500/30 flex items-center justify-center`}>
                        <Icon className={`w-5 h-5 ${colors.text}`} />
                      </div>
                      <span className="text-gray-300 font-semibold">{attr.name}</span>
                    </div>
                    <span className={`text-2xl font-bold ${colors.text}`}>{attr.value}</span>
                  </div>

                  <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${colors.bg} rounded-full transition-all duration-1000 ${colors.glow} shadow-lg`}
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Achievements */}
        <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/20 p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Award className="w-6 h-6 text-purple-400" />
            Conquistas Neurais
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {achievements.map((achievement) => {
              const colors = getColorClasses(achievement.color);
              const Icon = achievement.icon;

              return (
                <div
                  key={achievement.name}
                  className={`backdrop-blur-sm rounded-xl border p-5 transition-all ${
                    achievement.unlocked
                      ? `bg-${achievement.color}-500/10 border-${achievement.color}-500/30 hover:border-${achievement.color}-500/50`
                      : 'bg-black/20 border-white/10 opacity-50'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${achievement.unlocked ? `from-${achievement.color}-500/20` : 'from-gray-500/20'} to-transparent border ${achievement.unlocked ? `border-${achievement.color}-500/30` : 'border-gray-500/30'} flex items-center justify-center mb-3 mx-auto`}>
                    <Icon className={`w-6 h-6 ${achievement.unlocked ? colors.text : 'text-gray-600'}`} />
                  </div>
                  <p className={`text-center text-sm font-bold ${achievement.unlocked ? 'text-white' : 'text-gray-600'}`}>
                    {achievement.name}
                  </p>
                  {achievement.unlocked && (
                    <div className="flex items-center justify-center gap-1 mt-2">
                      <div className={`w-1.5 h-1.5 ${colors.bg} rounded-full`}></div>
                      <span className="text-xs text-gray-400">Desbloqueado</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Status Report */}
        <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-2xl border border-purple-500/30 p-6">
          <h3 className="text-lg font-bold text-purple-400 mb-4">Relatório de Status Neural</h3>
          <div className="space-y-3 text-sm text-gray-300">
            <div className="flex items-start gap-3">
              <span className="text-blue-400">▸</span>
              <p>Coerência mental operando com eficiência máxima.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-purple-400">▸</span>
              <p>Resiliência psicológica demonstra estabilidade excepcional.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-cyan-400">▸</span>
              <p>Trajetória de evolução cognitiva superando projeções base.</p>
            </div>
            <div className="flex items-start gap-3">
              <span className="text-pink-400">▸</span>
              <p>Índice de complexidade neural indica desenvolvimento avançado da consciência.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
