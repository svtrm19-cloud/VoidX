import { Brain, Zap, Target, TrendingUp, Activity, Eye, Cpu, Waves } from "lucide-react";
import { LineChart, Line, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar } from "recharts";

export function VoidDashboard() {
  const mentalData = [
    { time: "00:00", value: 65 },
    { time: "04:00", value: 45 },
    { time: "08:00", value: 75 },
    { time: "12:00", value: 85 },
    { time: "16:00", value: 70 },
    { time: "20:00", value: 60 },
  ];

  const radarData = [
    { metric: "Foco", value: 85 },
    { metric: "Energia", value: 72 },
    { metric: "Estabilidade", value: 78 },
    { metric: "Clareza", value: 90 },
    { metric: "Produtividade", value: 88 },
  ];

  const stats = [
    { label: "Energia Mental", value: 72, max: 100, color: "blue", icon: Zap },
    { label: "Produtividade", value: 88, max: 100, color: "purple", icon: Target },
    { label: "Nível de Foco", value: 85, max: 100, color: "cyan", icon: Eye },
    { label: "Consistência", value: 76, max: 100, color: "pink", icon: Activity },
    { label: "Estabilidade Emocional", value: 78, max: 100, color: "violet", icon: Waves },
    { label: "Evolução Cognitiva", value: 90, max: 100, color: "indigo", icon: TrendingUp },
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, any> = {
      blue: { text: "text-blue-400", bg: "bg-blue-500", glow: "shadow-blue-500/50", border: "border-blue-500/30" },
      purple: { text: "text-purple-400", bg: "bg-purple-500", glow: "shadow-purple-500/50", border: "border-purple-500/30" },
      cyan: { text: "text-cyan-400", bg: "bg-cyan-500", glow: "shadow-cyan-500/50", border: "border-cyan-500/30" },
      pink: { text: "text-pink-400", bg: "bg-pink-500", glow: "shadow-pink-500/50", border: "border-pink-500/30" },
      violet: { text: "text-violet-400", bg: "bg-violet-500", glow: "shadow-violet-500/50", border: "border-violet-500/30" },
      indigo: { text: "text-indigo-400", bg: "bg-indigo-500", glow: "shadow-indigo-500/50", border: "border-indigo-500/30" },
    };
    return colors[color];
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="backdrop-blur-xl bg-black/40 border-b border-purple-500/20">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="relative">
                  <Brain className="w-8 h-8 text-blue-400" />
                  <div className="absolute inset-0 bg-blue-500/30 rounded-full blur-xl animate-pulse"></div>
                </div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  VoidMind Omega System
                </h1>
              </div>
              <p className="text-sm text-gray-400 tracking-wider">PAINEL NEURAL • MONITORAMENTO EM TEMPO REAL</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-purple-400">23:47</div>
              <div className="text-xs text-gray-500">MAY 26, 2026</div>
            </div>
          </div>

          {/* User Status */}
          <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 backdrop-blur-sm rounded-2xl border border-purple-500/30 p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative w-16 h-16">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-pulse"></div>
                  <div className="absolute inset-1 bg-black rounded-full flex items-center justify-center">
                    <Cpu className="w-8 h-8 text-purple-400" />
                  </div>
                </div>
                <div>
                  <div className="text-xl font-bold text-white mb-1">Samuel Victor</div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-gray-400">Link Neural Ativo</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-400">Nível Mental</div>
                <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                  82
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Mental Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {stats.map((stat) => {
            const colors = getColorClasses(stat.color);
            const Icon = stat.icon;
            const percentage = (stat.value / stat.max) * 100;

            return (
              <div
                key={stat.label}
                className="group relative backdrop-blur-xl bg-white/5 rounded-2xl border border-white/10 p-5 hover:border-purple-500/40 transition-all duration-500"
              >
                {/* Glow Effect */}
                <div className={`absolute inset-0 ${colors.bg} opacity-0 group-hover:opacity-5 rounded-2xl blur-xl transition-opacity duration-500`}></div>

                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br from-${stat.color}-500/20 to-transparent border border-${stat.color}-500/30 flex items-center justify-center`}>
                      <Icon className={`w-6 h-6 ${colors.text}`} />
                    </div>
                    <div className={`text-3xl font-bold ${colors.text}`}>
                      {stat.value}
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="text-sm text-gray-400 mb-2 uppercase tracking-wider">{stat.label}</div>
                    <div className="h-2 bg-black/50 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${colors.bg} rounded-full transition-all duration-1000 ${colors.glow} shadow-lg`}
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 ${colors.bg} rounded-full animate-pulse`}></div>
                    <span className="text-xs text-gray-500">
                      {percentage >= 80 ? "Ótimo" : percentage >= 60 ? "Estável" : "Baixo"}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Neural Activity Chart */}
        <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-purple-500/20 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">Padrão de Atividade Neural</h3>
              <p className="text-sm text-gray-400">Monitoramento 24 Horas</p>
            </div>
            <Activity className="w-6 h-6 text-purple-400 animate-pulse" />
          </div>

          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={mentalData}>
              <Line
                type="monotone"
                dataKey="value"
                stroke="#8b5cf6"
                strokeWidth={2}
                dot={false}
                filter="drop-shadow(0 0 8px rgba(139, 92, 246, 0.6))"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Radar Chart */}
        <div className="backdrop-blur-xl bg-white/5 rounded-2xl border border-blue-500/20 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">Perfil Psicológico</h3>
              <p className="text-sm text-gray-400">Análise Multidimensional</p>
            </div>
            <Brain className="w-6 h-6 text-blue-400 animate-pulse" />
          </div>

          <ResponsiveContainer width="100%" height={250}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#4b5563" gridType="polygon" />
              <PolarAngleAxis dataKey="metric" stroke="#9ca3af" style={{ fontSize: '12px' }} />
              <Radar
                dataKey="value"
                stroke="#3b82f6"
                fill="#3b82f6"
                fillOpacity={0.3}
                filter="drop-shadow(0 0 12px rgba(59, 130, 246, 0.5))"
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* AI Insights */}
        <div className="backdrop-blur-xl bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-2xl border border-purple-500/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="relative">
              <div className="w-3 h-3 bg-purple-500 rounded-full animate-ping absolute"></div>
              <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
            </div>
            <h3 className="text-lg font-bold text-purple-400">VOID IA • Análise ao Vivo</h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3 text-sm text-gray-300">
              <div className="w-1 h-1 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <p>Detectando aumento de atividade cognitiva durante o período noturno.</p>
            </div>
            <div className="flex items-start gap-3 text-sm text-gray-300">
              <div className="w-1 h-1 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
              <p>Seu padrão de introspecção demonstra profundidade significativa.</p>
            </div>
            <div className="flex items-start gap-3 text-sm text-gray-300">
              <div className="w-1 h-1 bg-cyan-500 rounded-full mt-2 flex-shrink-0"></div>
              <p>A clareza mental permanece acima do limiar médio.</p>
            </div>
            <div className="flex items-start gap-3 text-sm text-gray-300">
              <div className="w-1 h-1 bg-pink-500 rounded-full mt-2 flex-shrink-0"></div>
              <p>Monitorando padrões de deterioração emocional coletiva.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
